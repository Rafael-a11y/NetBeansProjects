/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Av01Correcao;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author lcmnu
 */
public class Main {

    /**
     * Para cada pessoa o sistema deve perguntar, por meio de um método 
     * especifico (cadastrarCidadao): 
     * nome, o sexo, o peso, a idade, a altura,  
     * a data da aplicação da vacina e se o cidadão já havia testado positivo ou negativo 
     * antes da vacina e a RA – Região Administrativa de Brasília que esse cidadão mora. 
     * Para sinalizar o fim da lista será fornecido a palavra “fim” no nome do último 
     * cidadão. Após isso o sistema deve exibir um relatório, por meio de outro método 
     * (exibirRelatorio), contendo:
        i. A quantidade de cidadãos cadastrados e que tomaram a segunda dose. 
        ii. A quantidade de cidadãos do sexo masculino e feminino que testaram positivo para COVID19, antes da vacinação; 
        iii. A média da idade dos cidadãos, independente do sexo, que testaram positivo para COVID19; 
        iv. A RA – Região Administrativa com maior quantidade de casos de COVID19 e a quantidade de casos dessa região.
        v. A idade e nome do cidadão mais velho que recebeu a segunda dose;
        vi. A idade e nome do cidadão mais novo que recebeu a segunda dose;
     */
    public static void main(String[] args) 
    {
        ArrayList<Paciente> lista = new ArrayList<Paciente>();
        Paciente p = null;
        String saida = "nao";
        int ra = 0, sexo = 0, teveCovid = 0;
        
        JOptionPane.showMessageDialog(null, "Cadastro de Pacientes");
        
        do
        {
            try 
            {
                p = new Paciente();
                p.setNome(JOptionPane.showInputDialog(null, "Digite a nome do Paciente:"));
                sexo = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite 1 - Masc ou 2 - Fem:"));
                if(sexo == 1)
                    p.setSex(Enums.Sexo.masc);
                else
                    p.setSex(Enums.Sexo.fem);
                p.setIdade(Integer.parseInt((JOptionPane.showInputDialog(null, "Digite a idade do Paciente:"))));            
                p.setAltura(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a Altura do Paciente:")));
                ra = Integer.parseInt(JOptionPane.showInputDialog(null, "Onde você mora? \n 1- Guara;\n 2- Taguatinga;\n 3- Asa Norte;\n 4- Recanto; \n 5- Planaltina; \n 6- Ceilandia;"));
                switch(ra)
                {
                    case 1:
                        p.setEndereco(Enums.RA.Guara);
                        break;
                    case 2:
                        p.setEndereco(Enums.RA.Taguatinga);
                        break;
                    case 3:
                        p.setEndereco(Enums.RA.Asa_norte);
                        break;
                    case 4:
                        p.setEndereco(Enums.RA.Recanto);
                        break;
                    case 5:
                        p.setEndereco(Enums.RA.Planaltina);
                        break;
                    case 6:
                        p.setEndereco(Enums.RA.Ceilandia);
                        break;
                    default:
                        p.setEndereco(Enums.RA.Guara);
                        break;
                }

                p.setDataSegundaDose(JOptionPane.showInputDialog(null, "Data segunda dose:"));

                teveCovid = Integer.parseInt(JOptionPane.showInputDialog(null, "Já teve COVID 19? 1 - sim ou 2 - não:"));
                if(teveCovid == 1)
                    p.setCovid(Enums.teveCovid.sim);
                else
                    p.setCovid(Enums.teveCovid.nao);

                lista.add(p);
                
                saida = JOptionPane.showInputDialog(null, "Digite 'fim' caso deseje sair ou 99 para continuar.");
            } 
            catch (Exception e) 
            {
                System.out.println("ERRO: " + e.getMessage());
            }
                        
        }while(!saida.equals("fim"));
        
        JOptionPane.showMessageDialog(null, p.exibirRelatorio(lista));
    }
}
