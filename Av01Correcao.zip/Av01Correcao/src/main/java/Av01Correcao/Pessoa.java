/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Av01Correcao;

/**
 *
 * @author lcmnu
 */
public abstract class Pessoa 
{
    private String nome;
    private Enums.Sexo sex;
    private Double peso;
    private int idade;
    private Double altura;
    private Enums.RA endereco;

    public Pessoa() {
    }

    public Pessoa(String nome, Enums.Sexo sex, Double peso, int idade, Double altura, 
            Enums.RA endereco) {
        this.nome = nome;
        this.sex = sex;
        this.peso = peso;
        this.idade = idade;
        this.altura = altura;
        this.endereco = endereco;
    }
    
    public Double getAltura() {
        return altura;
    }

    public void setAltura(Double altura) {
        this.altura = altura;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Enums.Sexo getSex() {
        return sex;
    }

    public void setSex(Enums.Sexo sex) {
        this.sex = sex;
    }

    public Double getPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Enums.RA getEndereco() {
        return endereco;
    }

    public void setEndereco(Enums.RA endereco) {
        this.endereco = endereco;
    }
    
    public abstract String toString();
}
