/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Av01Correcao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author lcmnu
 */
public class Paciente extends Pessoa{

    //private ArrayList<Paciente> listaPacientes = new ArrayList<Paciente>();
    private String dataSegundaDose;
    private Enums.teveCovid covid;

    public Paciente() {
    }

    public Paciente(String dataSegundaDose, Enums.teveCovid covid, 
            String nome, Enums.Sexo sex, Double peso, int idade, 
            Double altura, Enums.RA endereco) {
        super(nome, sex, peso, idade, altura, endereco);
        this.dataSegundaDose = dataSegundaDose;
        this.covid = covid;
    }

    public Enums.teveCovid getCovid() {
        return covid;
    }

    public void setCovid(Enums.teveCovid covid) {
        this.covid = covid;
    }

    public String getDataSegundaDose() {
        return dataSegundaDose;
    }

    public void setDataSegundaDose(String dataSegundaDose) {
        this.dataSegundaDose = dataSegundaDose;
    }
    
    /*
    i. A quantidade de cidadãos cadastrados e que tomaram a segunda dose. 
    ii. A quantidade de cidadãos do sexo masculino e feminino que testaram positivo para COVID19, antes da vacinação; 
    iii. A média da idade dos cidadãos, independente do sexo, que testaram positivo para COVID19; 
    iv. A RA – Região Administrativa com maior quantidade de casos de COVID19 e a quantidade de casos dessa região.
    v. A idade e nome do cidadão mais velho que recebeu a segunda dose;
    vi. A idade e nome do cidadão mais novo que recebeu a segunda dose;
    */
    public String exibirRelatorio(ArrayList<Paciente> pLista) 
    {
        int mascCovid = 0, femCovid = 0, qtdeRaMaisCovid  = 0, 
                idadeAux = 0, idadeMaisVelho = 0, idadeMaisNovo = 999, totalPositivoCovid = 0,
                raGuara = 0, raTaguatinga = 0, raAsaNorte = 0, raRecanto = 0,
                raPlanaltina = 0, raCeilandia = 0, somaIdadesPositivo = 0;
        double mediaIdadePositivoCovid = 0;
        
        Enums.RA raMaisCovid;
        String nomeCidadaoVelho = "", nomeCidadaoNovo = "";
        Paciente pAux = null;
        
        for (int i = 0; i < pLista.size(); i++) 
        {
            pAux = pLista.get(i);
            
            //Cidadãos que testaram positivo
            if(pAux.covid == Enums.teveCovid.sim)
            {
                if(pAux.getSex() == Enums.Sexo.fem)
                    femCovid++;
                else
                    mascCovid++;
                
                //Total dos cidadãos que testaram positivo, fora do for eu faço a média
                totalPositivoCovid++;
                somaIdadesPositivo+= pAux.getIdade();
                
                //Verificando a RA que teve covid e depois vendo a maior
                switch(pAux.getEndereco())
                {
                    case Guara:
                        raGuara++;
                        break;
                    case Taguatinga:
                        raTaguatinga++;
                        break;
                    case Asa_norte:
                        raAsaNorte++;
                        break;
                    case Recanto:
                        raRecanto++;
                        break;
                    case Planaltina:
                        raPlanaltina++;
                        break;
                    case Ceilandia:
                        raCeilandia++;
                        break;
                }
                
                idadeAux = pAux.getIdade();
                //Verificando o nome mais velho e idade
                if(idadeAux >= idadeMaisVelho)
                {
                    idadeMaisVelho = idadeAux;
                    nomeCidadaoVelho = pAux.getNome();
                }
                else if(idadeAux <= idadeMaisNovo)
                {
                    idadeMaisNovo = idadeAux;
                    nomeCidadaoNovo = pAux.getNome();
                }
            }
        }
        
        ArrayList<String> listaRA = new ArrayList<String>(
            Arrays.asList("Guará", "Taguatinga", "Asa norte", 
                    "Recanto", "Planaltina", "Ceilandia"));
        ArrayList<Integer> rasCovid = new ArrayList<Integer>(
                Arrays.asList(raGuara, raTaguatinga, 
                        raAsaNorte, raRecanto, raPlanaltina, raCeilandia));
        
        mediaIdadePositivoCovid = somaIdadesPositivo/totalPositivoCovid;
        
        return "------RELATÓRIO FINAL------\n" +
               "Quantidade de vacinados (2ª dose): " + retornarTotalPacientes(pLista) + ";\n" +
               "Masculino positivo COVID19: " + mascCovid + "; \n" +
               "Feminino positivo COVID19: " + femCovid + "; \n" +
               "Média idades positivo COVID19: " + mediaIdadePositivoCovid + "; \n" + 
               "Qtde RA com mais casos de COVID19: " + Collections.max(rasCovid) + "; \n" +
               "Cidão mais velho COVID19: " + nomeCidadaoVelho + " - Idade: "+ idadeMaisVelho +"; \n" +
               "Cidão mais novo COVID19: " + nomeCidadaoNovo + " - Idade: "+ idadeMaisNovo +"; \n" +
               "------FIM RELATÓRIO------";
    }
    
    public void cadastrarCidadao(Paciente p, ArrayList<Paciente> pLista)
    {
        pLista.add(p);
    }
    
    public int retornarTotalPacientes(ArrayList<Paciente> pLista)
    {
        return pLista.size();
    }

    @Override
    public String toString() {
        return "";
    }
}
